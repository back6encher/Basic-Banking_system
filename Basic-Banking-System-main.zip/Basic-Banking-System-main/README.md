# Saprk Foundation Banking system

Sparks Foundation Internship Project : Basic Banking System  
A Web Application used to transfer money between multiple users.  

Stack used - 
Front-end : HTML, CSS, Bootstrap
Back-end : PHP 
Database : MySQL   

Flow : Home page -> view all customer -> select and view one customer -> Transfer money -> Select customer to transfer to -> Transaction history -> view all customer
