<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>navbar</title>
    <link rel="stylesheet" href="navbar.css"/>
</head>
<body>
    <div class="nav">
        <ul>
            <a href="index.php"><li>Home</li></a>
            <a href="transfermoney.php"><li>Transfer Money</li></a>
            <a href="transactionhis.php"><li>History</li></a>
        </ul>
    </div>
</body>
</html>